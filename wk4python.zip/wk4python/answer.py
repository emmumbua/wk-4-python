def read_and_modify_file():
    # Ask the user for the filename
    input_filename = input("Please enter the filename to read: ")
    output_filename = "modified_" + input_filename

    try:
        # Attempt to open the file for reading
        with open(input_filename, 'r') as file:
            # Read the contents of the file
            contents = file.readlines()

        # Modify the contents (for example, converting to uppercase)
        modified_contents = [line.upper() for line in contents]

        # Write the modified contents to a new file
        with open(output_filename, 'w') as new_file:
            new_file.writelines(modified_contents)

        print(f"Modified file has been created: {output_filename}")

    except FileNotFoundError:
        print(f"Error: The file '{input_filename}' does not exist.")
    except IOError:
        print(f"Error: The file '{input_filename}' cannot be read.")
    except Exception as e:
        print(f"An unexpected error occurred: {e}")

# Run the function
read_and_modify_file()
